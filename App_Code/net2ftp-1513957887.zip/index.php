<?php
$ads_1 = "<style>#M297233ScriptRootC183662 {min-height: 300px;}</style><div id=\"M297233ScriptRootC183662\"><div id=\"M297233PreloadC183662\"></div><script> (function(){ var D=new Date(),d=document,b='body',ce='createElement',ac='appendChild',st='style',ds='display',n='none',gi='getElementById'; var i=d[ce]('iframe');i[st][ds]=n;d[gi](\"M297233ScriptRootC183662\")[ac](i);try{var iw=i.contentWindow.document;iw.open();iw.writeln(\"<ht\"+\"ml><bo\"+\"dy></bo\"+\"dy></ht\"+\"ml>\");iw.close();var c=iw[b];} catch(e){var iw=d;var c=d[gi](\"M297233ScriptRootC183662\");}var dv=iw[ce]('div');dv.id=\"MG_ID\";dv[st][ds]=n;dv.innerHTML=183662;c[ac](dv); var s=iw[ce]('script');s.async='async';s.defer='defer';s.charset='utf-8';s.src=\"//jsc.mgid.com/t/i/tinnhe.com.183662.js?t=\"+D.getYear()+D.getMonth()+D.getDate()+D.getHours();c[ac](s);})();  </script></div>";
$ads_2 = "<style>#M297233ScriptRootC183845 {min-height: 300px;}</style><div id=\"M297233ScriptRootC183845\">         <div id=\"M297233PreloadC183845\"></div>         <script>                 (function(){             var D=new Date(),d=document,b='body',ce='createElement',ac='appendChild',st='style',ds='display',n='none',gi='getElementById';             var i=d[ce]('iframe');i[st][ds]=n;d[gi](\"M297233ScriptRootC183845\")[ac](i);try{var iw=i.contentWindow.document;iw.open();iw.writeln(\"<ht\"+\"ml><bo\"+\"dy></bo\"+\"dy></ht\"+\"ml>\");iw.close();var c=iw[b];}             catch(e){var iw=d;var c=d[gi](\"M297233ScriptRootC183845\");}var dv=iw[ce]('div');dv.id=\"MG_ID\";dv[st][ds]=n;dv.innerHTML=183845;c[ac](dv);             var s=iw[ce]('script');s.async='async';s.defer='defer';s.charset='utf-8';s.src=\"//jsc.mgid.com/t/i/tinnhe.com.183845.js?t=\"+D.getYear()+D.getMonth()+D.getDate()+D.getHours();c[ac](s);})();     </script> </div>";
$ads_3 = "<div id=\"SC_TBlock_447169\" class=\"SC_TBlock\">.</div> <script type=\"text/javascript\">var SC_CId = \"447169\",SC_Domain=\"n.pc1ads.com\";SC_Start_447169=(new Date).getTime();</script><script type=\"text/javascript\" src=\"//st-n.pc1ads.com/js/adv_out.js\"></script>";
$ads_r = "<div id=\"M297233ScriptRootC183775\">  <div id=\"M297233PreloadC183775\"></div>         <script>                 (function(){             var D=new Date(),d=document,b='body',ce='createElement',ac='appendChild',st='style',ds='display',n='none',gi='getElementById';             var i=d[ce]('iframe');i[st][ds]=n;d[gi](\"M297233ScriptRootC183775\")[ac](i);try{var iw=i.contentWindow.document;iw.open();iw.writeln(\"<ht\"+\"ml><bo\"+\"dy></bo\"+\"dy></ht\"+\"ml>\");iw.close();var c=iw[b];}             catch(e){var iw=d;var c=d[gi](\"M297233ScriptRootC183775\");}var dv=iw[ce]('div');dv.id=\"MG_ID\";dv[st][ds]=n;dv.innerHTML=183775;c[ac](dv);             var s=iw[ce]('script');s.async='async';s.defer='defer';s.charset='utf-8';s.src=\"//jsc.mgid.com/t/i/tinnhe.com.183775.js?t=\"+D.getYear()+D.getMonth()+D.getDate()+D.getHours();c[ac](s);})();     </script></div>";
$page = $_GET['p'];
$id = urlencode($_GET['transon']);
$url = "http://truyenfun.com/".$id."?p=".$page;
$trinhduyet = 'NokiaN97/21.1.107 (SymbianOS/9.4; Series60/5.0 Mozilla/5.0; Profile/MIDP-2.1 Configuration/CLDC-1.1) AppleWebkit/525 (KHTML, like Gecko) BrowserNG/7.1.4';
$c=curl_init();
curl_setopt($c, CURLOPT_URL, $url);
curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($c, CURLOPT_USERAGENT, $trinhduyet);
curl_setopt($c, CURLOPT_REFERER, 'http://grab.buycode.tk');
$nd=curl_exec($c);
curl_close($c);
$nd= preg_replace('#<script(.*?)</script>#is',"",$nd);
$nd = str_replace('truyenfun.com','grab.buycode.tk',$nd);
$nd = str_replace('grab.buycode.tk/file','truyenfun.com/file',$nd);
$nd = str_replace('TruyenFun','Grab',$nd);
$nd = str_replace('.Com','.Tk',$nd);

$nd= preg_replace('#<div class="rela"><div class="center" style="max-width:100%;word-wrap: break-word;">(.*?)</div></div>#is','',$nd);
$nd = str_replace('</body>','.<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="http://truyenfun.com/files/doctruyen.js" type="text/javascript" async></script>
<script type="text/javascript" src="http://truyenfun.com/files/js/m.player.js">
<script type="text/javascript">$(function () {$(document).bind(\'contextmenu\',function(e){e.preventDefault();});});</script>
</body>',$nd);
echo $nd;
?>
